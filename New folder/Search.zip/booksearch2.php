<?php require_once('connect.php'); ?>
<!DOCTYPE html>
<html>
<body>

<h1>Welcome to BookBig</h1>

<p>Please type the name of book you want to search:</p>
	<form action="" method="POST">
		<input type="text" name="input" value="" />
		<input type="submit" value="search" />
	</form>		
	<?php
		echo 'Hello';
		
			$search=$_POST['input'];
			/*$exists="SELECT EXISTS(SELECT BookName,Writer,Publisher,Category,Totalpage,BookPrice 
			FROM BookDetails
			INNER JOIN BookPriceDetails
			ON BookDetails.BookID=BookPriceDetails.BookID
			WHERE BookName LIKE '%HARRY%')"*/
			/*$q="SELECT BookName,Writer,Publisher,Category,Totalpage,BookPrice FROM BookDetails INNER JOIN BookPriceDetails ON BookDetails.BookID=BookPriceDetails.BookID WHERE BookName LIKE '%'$search'%'";*/
			$q="SELECT * FROM BookDetails";
			$result =$mysqli->query($q);
			$row=$result->fetch_array();
			echo $row['BookName'];
			if(!$result){
						echo"Title not found on our database".$mysqli->error;
					}
				
			?>
		
		

</body>
</html>